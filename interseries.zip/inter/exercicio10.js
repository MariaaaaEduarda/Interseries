const time = {
    nome: "Gatos",
    cor: "Preto",
    turma: "1A",
    mascote: "Gato",
    atletas: ["Monique", "Amanda", "Vicky", "Beatriz", "João", "Maria"], 
    esporteEscolhido: "Futebol"
};

function listarAtletas() {
    console.log("Os atletas do time são:");
    for (let i = 0; i < time.atletas.length; i++) {
        console.log((i + 1), time.atletas[i]);
    }
}

function mostrarPerfilTime() {
    console.log("Nome do time: " , time.nome);
    console.log("Cor do time: " , time.cor);
    console.log("Turma: " , time.turma);
    console.log("Mascote: " , time.mascote);
    listarAtletas();
    console.log("Esporte escolhido: " , time.esporteEscolhido);

    if (time.atletas.length > 5) {
        console.log("Parabéns, seu time tem mais de 5 atletasss!");
    }
}
mostrarPerfilTime();
