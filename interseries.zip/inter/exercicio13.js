let time = {
    nome: "Gatos",
    cor: "Preto",
    turma: "1AT",
    mascote: "Gatos",
    atletas: ["Monique", "Amanda", "Vicky", "Beatriz", "João", "Maria"], 
    esportes: ['futebol', 'basquete'],
    pontuacao: 0 
}
function adicionarPontos() {
    let pontos = prompt("quantos pontos voce vai adicionar?")
    let pontosNumero = + pontos
  
    if (pontosNumero === pontosNumero && pontosNumero > 0) {
      time.pontuacao += pontosNumero
      console.log("pontuação total é: " + time.pontuacao)
    } else {
      console.log("numero invalido")
    }
  }
  function encerrarInterseries() {
    console.log("nome: " + time.nome)
    console.log("cor: " + time.cor)
    console.log("turma: " + time.turma)
    console.log("mascote: " + time.mascote)
    
    console.log("atletas")
    for (let i = 0; i < time.atletas.length; i++) {
      console.log((i + 1)  + time.atletas[i])
    }
    console.log("esportes escolhidos:")
    for (let i = 0; i < time.esportes.length; i++) {
      console.log((i + 1) + time.esportes[i])
    }
    console.log("pontuação final: " + time.pontuacao)
  
    if (time.pontuacao > 50) {
      console.log("parabens, o time conseguiu uma pontuação incrível")
    }
  }
  adicionarPontos()
    encerrarInterseries()