let time = {
    esportes: []
  }
    function adicionarEsporte() {
    let esporte = prompt("escolha um esporte para adicionar, futeol, vôlei, basquete, xadrez ou fifa")
    time.esportes.push(esporte)
    console.log(esporte , "foi adicionado ao time")
  }
    function removerEsporte() {
    const esporte = prompt("tire um esporte:")
    for (let i = 0; i < time.esportes.length; i++) {
      if (time.esportes[i] === esporte) {
        time.esportes.splice(i, 1)
        console.log(esporte , "foi removido do time:")
        return
      }
    }
  }
  adicionarEsporte()
  adicionarEsporte()
  
  console.log("os esportes são:")
  for (let i = 0; i < time.esportes.length; i++) {
    console.log((i + 1) + time.esportes[i])
  }
  removerEsporte()
  console.log("os esportes agora são:")
  for (let i = 0; i < time.esportes.length; i++) {
    console.log((i + 1) +  time.esportes[i])
  }