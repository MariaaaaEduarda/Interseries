let nome = prompt("qual o nome do time?")
let cor = prompt("qual é a cor do time?")
let turma = prompt("qual é a turma do seu time?")
let mascote = prompt("qual é o mascote do seu time?")

console.log("nome do time: " + nome)
console.log("cor do time: " + cor)
console.log("turma: " + turma)
console.log("mascote: " + mascote)

console.log("bem vindo, ", nome ," da ", turma , "! a cor do time é " , cor , " e o mascote é um" , mascote)