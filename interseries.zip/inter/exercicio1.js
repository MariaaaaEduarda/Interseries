let nome = "Gatos"
let cor = "Preta"
let turma = "1AT"
let mascote = "Gato"

console.log("Nome do time: " + nome)
console.log("Cor do time: " + cor)
console.log("Turma: " + turma)
console.log("Mascote: " + mascote)

console.log("bem vindo a, " + nome + " da " + turma + "!")