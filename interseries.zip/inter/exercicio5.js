let esportes = ["futebol", "volei", "basquete", "xadrez", "fifa"]
let esporteEscolhido = prompt("qual esporte seu time deseja participar? (futebol, volei, basquete, xadrez ou fifa)")

if(esportes.includes(esporteEscolhido)) {
    if (esporteEscolhido === "futebol") {
        console.log("você escolheu um esporte popular!")
      } else if (esporteEscolhido === "fifa") {
        console.log('você escolheu um esporte popular!')
    } else {
        console.log(`você escolheu ${esporteEscolhido}`)
      }
    } else {
      console.log("esporte não disponível")
    }