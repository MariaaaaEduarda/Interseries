const time = {
    nome: "Gatos",
    cor: "Preto",
    turma: "1A",
    mascote: "Gato",
    atletas: ["Monique", "Amanda", "Vicky", "Beatriz", "João", "Maria"], 
    esporteEscolhido: "Futebol"
};

function listarAtletas() {
    console.log("Os atletas do time são:");
    for (let i = 0; i < time.atletas.length; i++) {
        console.log((i + 1), time.atletas[i]);
    }
}

function mostrarPerfilTime() {
    console.log("Nome do time: " , time.nome);
    console.log("Cor do time: " , time.cor);
    console.log("Turma: " , time.turma);
    console.log("Mascote: " , time.mascote);
    listarAtletas();
    console.log("Esporte escolhido: " , time.esporteEscolhido);
    console.log("Pontuação atual: " , time.pontuacao);
}

function adicionarPontos(pontos) {
    time.pontuacao += pontos; 
    console.log("Pontuação renovada, total de pontos: " + time.pontuacao); 
}

mostrarPerfilTime();

const pontosParaAdicionar = prompt("Quantos pontos você deseja adicionar ao time?");
if (pontosParaAdicionar) {
    adicionarPontos(Number(pontosParaAdicionar));
}
mostrarPerfilTime(); 