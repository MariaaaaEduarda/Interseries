function listarAtletas(atletas) {
    console.log("os atletas do time sao: ")
    for (let i = 0; i < atletas.length; i++) {
      console.log(i + 1 + atletas[i])
    }
  }  function adicionarAtleta(atletas) {
    let novoAtleta = prompt("Digite o nome para um novo atleta: ")
    atletas[atletas.length] = novoAtleta 
    console.log(novoAtleta , "fé seu novo atleta!")
  }
    let atletas = ["Caio", "Marcos", "Henrique", "Bernardo", "Edson"]
  
  listarAtletas(atletas)
    adicionarAtleta(atletas)
  listarAtletas(atletas)
  