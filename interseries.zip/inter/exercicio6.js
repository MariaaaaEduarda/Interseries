const atletas = ["Arnold", "Guilherme", "João", "Sofia", "Gustavo"];
console.log("Os atletas do time são:");
for (let i = 0; i < atletas.length; i++) {
    console.log((i + 1) + ". " + atletas[i]);
}
