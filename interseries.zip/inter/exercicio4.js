let atletas = ["Arnold", "Guilherme", "João", "Sofia", "Gustavo"]

console.log("os atletas do time são: " + atletas)

let novoAtleta = prompt("adicione mais um atleta:")

atletas.push(novoAtleta)

console.log("todos os atletas do time: " + atletas)