let time = {
    nome: "Gatos",
    cor: "Preto",
    turma: "1AT",
    mascote: "Gato",
    atletas: ["Monique", "Amanda", "Vicky", "Beatriz", "João", "Maria"], 
    esportes: ['futebol', 'basquete']
}
function alterarMascote() {
    let novoMascote = prompt("digite o novo nome do mascote:")
    
    time.mascote = novoMascote
    
    console.log("o novo mascote do time é " , novoMascote)
  }
  alterarMascote()