let gritoDeGuerra = prompt("qual é o grito de guerra do seu time?")

console.log("Seu grito de guerra em LETRAS MAIUSCULAS: " + gritoDeGuerra.toUpperCase())

console.log("Seu grito de guerra em letras minusculas: " + gritoDeGuerra.toLowerCase())